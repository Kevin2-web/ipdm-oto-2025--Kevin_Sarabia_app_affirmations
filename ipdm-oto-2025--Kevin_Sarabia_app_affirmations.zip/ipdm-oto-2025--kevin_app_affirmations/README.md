# Affirmations App

Este proyecto es la entrega combinada de los ejercicios 2 y 3 del curso oficial de Android en la ruta "Crea una Lista Desplazable".

## ✅ Incluye:
- Lista desplazable con Jetpack Compose (`LazyColumn`).
- Tarjetas con imágenes y texto usando `Card`, `Image`, `Text`.
- Ícono adaptable personalizado con `Image Asset Studio`.

## 📷 Captura de pantalla
La app muestra afirmaciones en una lista vertical:

![captura](captures/captura_app_affirmations.png)

## ▶️ Cómo ejecutar
1. Abre este proyecto en Android Studio.
2. Ejecuta en un emulador o dispositivo físico.
3. Verifica que aparezca la lista y el nuevo ícono.

---

**Kevin - IPDM Otoño 2025**
